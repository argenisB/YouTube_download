# youtube-downloader-converter
A simple Python script that is able to download YouTube videos or playlists and convert them into MP3.

Copyright (c) NeuralNine 2020 - YouTube Downloader v0.2 Alpha

WARNING: DOWNLOADING COPYRIGHTED MATERIAL IS HIGHLY ILLEGAL!
I DO NOT TAKE ANY RESPONSIBILITY FOR YOUR USAGE OF THIS TOOL!
THIS IS FOR EDUCATIONAL PURPOSES ONLY!
